// Package my_module is a Metricbeat module that contains MetricSets.
package my_module
